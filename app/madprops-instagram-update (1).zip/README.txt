Upload the app folder from this download to the MAIN page of your GitHub repository using Add file > Upload files. Commit the four files together. They replace your existing files and keep your existing photos.

Changes: cream top bar removed; cream Step Right Up button below hero image; all visible form fields required except phone; exact positive whole-dollar budget; gallery replaced by native Instagram profile embed.

Instagram must be public and allow embeds. Instagram controls this preview; it is not a custom full-width feed. Rendering can be restricted by Instagram or browser privacy settings. A direct Instagram link remains available.

Build passed and seven server validation cases passed using a mocked email service. No actual email was sent. Live Instagram rendering and email delivery still require verification after deployment.
