# Activate direct inquiry delivery on Vercel

These files install the approved carnival homepage with the two removed sections, full desktop width, and on-page contact form. Existing metadata and images remain in place.

1. Connect Resend to this Vercel project: https://vercel.com/marketplace/resend
2. Add and verify a sending domain in Resend. A subdomain such as `mail.madpropsevent.co` keeps sending setup separate from your existing inbox. Add only the DNS records Resend requests for that subdomain; do not replace your existing inbox's MX records.
3. In Vercel → Project → Settings → Environment Variables, set `RESEND_API_KEY` (secret, never NEXT_PUBLIC) and `CONTACT_FROM_EMAIL` (e.g. `Mad Props Website <website@mail.madpropsevent.co>` after that domain is verified). Enable for the deployment environments you intend to test/use.
4. Redeploy after setting variables. Upload the included app/ files into the same paths in your GitHub repository (replace app/page.jsx). Keep your existing public/ assets and layout. Commit when ready to update production.
5. Submit a clearly labeled test from the deployed form and confirm it arrives at madison@madpropsevent.co. Check spam and Resend delivery logs if necessary.

The recipient is fixed on the server; Reply-To is the visitor's email. The form retains inputs on failure and resets only after Resend accepts the email. Acceptance is not proof of inbox delivery. Without credentials it returns an honest unavailable message, never a false success. No email has been sent during development.

Validation: server checks required fields, types, lengths, JSON and same-origin browser requests. Includes a honeypot and disables repeat clicks while submitting. These are basic abuse controls, not a distributed rate limiter. Configure Vercel Firewall rate limiting for /api/contact before broad public promotion.

No additional npm packages are needed. Run `npm run build` with the repository's existing dependencies. Tests use mocked Resend responses and do not send email.

Build note: the repository currently uses Next.js 14.2.3. npm flags that existing version as vulnerable; upgrade to a currently patched Next.js version before production deployment. No dependency upgrades are included in this scoped change.
